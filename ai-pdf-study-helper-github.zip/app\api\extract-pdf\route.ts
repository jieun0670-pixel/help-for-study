import { NextResponse } from "next/server";
import pdfParse from "pdf-parse";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "PDF 파일을 찾을 수 없습니다." }, { status: 400 });
    }

    if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
      return NextResponse.json({ error: "PDF 파일만 업로드할 수 있습니다." }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const parsed = await pdfParse(Buffer.from(bytes));
    const text = parsed.text.replace(/\s+/g, " ").trim();

    if (!text) {
      return NextResponse.json(
        { error: "PDF에서 읽을 수 있는 텍스트를 찾지 못했습니다." },
        { status: 422 }
      );
    }

    return NextResponse.json({
      fileName: file.name,
      pages: parsed.numpages,
      text,
      summary: text.slice(0, 700)
    });
  } catch {
    return NextResponse.json(
      { error: "PDF를 분석하는 중 문제가 발생했습니다. 텍스트가 포함된 PDF인지 확인해 주세요." },
      { status: 500 }
    );
  }
}
