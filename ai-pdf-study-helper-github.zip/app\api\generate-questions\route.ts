import { NextResponse } from "next/server";
import type { Difficulty, StudyQuestion } from "@/app/types";
import { buildSampleQuestions } from "@/lib/sampleQuestions";

export const runtime = "nodejs";

function extractJson(text: string) {
  const start = text.indexOf("[");
  const end = text.lastIndexOf("]");
  if (start === -1 || end === -1) {
    throw new Error("JSON array not found");
  }
  return JSON.parse(text.slice(start, end + 1));
}

function isDifficulty(value: unknown): value is Difficulty {
  return value === "하" || value === "중" || value === "상";
}

function normalizeQuestions(raw: StudyQuestion[], difficulty: Difficulty): StudyQuestion[] {
  return raw.slice(0, 17).map((question, index) => ({
    id: question.id || `Q${String(index + 1).padStart(2, "0")}`,
    type: question.type,
    question: question.question,
    choices: question.choices || [],
    answer: question.answer,
    explanation: question.explanation,
    concept: question.concept,
    difficulty,
    keywords: question.keywords || question.answer.split(/\s+/).filter(Boolean).slice(0, 4)
  }));
}

export async function POST(request: Request) {
  try {
    const { text, difficulty } = (await request.json()) as {
      text?: string;
      difficulty?: unknown;
    };

    if (!text || !isDifficulty(difficulty)) {
      return NextResponse.json({ error: "PDF 텍스트와 난이도를 확인해 주세요." }, { status: 400 });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        source: "sample",
        questions: buildSampleQuestions(text, difficulty)
      });
    }

    const prompt = `
PDF 강의자료 내용을 바탕으로 한국어 학습 문제 17개를 생성해 주세요.
난이도: ${difficulty}

조건:
- O/X 문제 5개, 객관식 문제 10개, 서술형 문제 2개
- 각 문제는 id, type, question, choices, answer, explanation, concept, difficulty, keywords를 포함
- type은 OX, MULTIPLE_CHOICE, SHORT_ANSWER 중 하나
- OX choices는 ["O","X"]
- 객관식 choices는 보기 4개
- 서술형 choices는 []
- 정답과 해설은 명확하게 작성
- keywords는 서술형 임시 채점에 사용할 핵심어 3~5개
- JSON 배열만 출력

자료:
${text.slice(0, 12000)}
`;

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        temperature: 0.35,
        messages: [
          {
            role: "system",
            content: "You generate valid JSON only. Do not include markdown fences."
          },
          { role: "user", content: prompt }
        ]
      })
    });

    if (!response.ok) {
      return NextResponse.json({
        source: "sample",
        questions: buildSampleQuestions(text, difficulty)
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";
    const questions = normalizeQuestions(extractJson(content), difficulty);

    if (questions.length !== 17) {
      return NextResponse.json({
        source: "sample",
        questions: buildSampleQuestions(text, difficulty)
      });
    }

    return NextResponse.json({ source: "openai", questions });
  } catch {
    return NextResponse.json({ error: "문제를 생성하지 못했습니다." }, { status: 500 });
  }
}
