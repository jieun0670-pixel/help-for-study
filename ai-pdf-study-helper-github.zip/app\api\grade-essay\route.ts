import { NextResponse } from "next/server";

export const runtime = "nodejs";

function keywordGrade(answer: string, keywords: string[]) {
  const normalized = answer.toLowerCase();
  const hits = keywords.filter((keyword) => normalized.includes(keyword.toLowerCase())).length;
  const ratio = keywords.length ? hits / keywords.length : 0;
  const score = Math.round(ratio * 10);

  return {
    score,
    isCorrect: score >= 6,
    feedback:
      score >= 8
        ? "핵심 키워드를 충분히 포함했습니다."
        : score >= 6
          ? "주요 키워드는 담겼지만 설명을 조금 더 구체화하면 좋습니다."
          : "핵심 키워드가 부족합니다. 관련 개념을 다시 확인해 보세요."
  };
}

export async function POST(request: Request) {
  try {
    const { question, correctAnswer, userAnswer, keywords } = (await request.json()) as {
      question: string;
      correctAnswer: string;
      userAnswer: string;
      keywords?: string[];
    };

    const safeKeywords = keywords?.length ? keywords : correctAnswer.split(/\s+/).slice(0, 5);
    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
      return NextResponse.json(keywordGrade(userAnswer || "", safeKeywords));
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        temperature: 0,
        messages: [
          {
            role: "system",
            content:
              "Grade the Korean short answer from 0 to 10. Return JSON only: {\"score\":number,\"isCorrect\":boolean,\"feedback\":\"string\"}."
          },
          {
            role: "user",
            content: `문제: ${question}\n모범답안: ${correctAnswer}\n학생답안: ${userAnswer}`
          }
        ]
      })
    });

    if (!response.ok) {
      return NextResponse.json(keywordGrade(userAnswer || "", safeKeywords));
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "{}";
    const parsed = JSON.parse(content.slice(content.indexOf("{"), content.lastIndexOf("}") + 1));

    return NextResponse.json({
      score: Math.max(0, Math.min(10, Math.round(Number(parsed.score) || 0))),
      isCorrect: Boolean(parsed.isCorrect ?? Number(parsed.score) >= 6),
      feedback: String(parsed.feedback || "AI 채점이 완료되었습니다.")
    });
  } catch {
    return NextResponse.json({ error: "서술형 채점에 실패했습니다." }, { status: 500 });
  }
}
