"use client";

import { useMemo, useRef, useState } from "react";
import type { Difficulty, EssayGrade, GradedQuestion, StudyQuestion, StudyReport } from "@/app/types";

const firebaseDatabaseUrl =
  process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL ||
  "https://help-for-study-default-rtdb.firebaseio.com";

const difficultyCards: Array<{
  value: Difficulty;
  title: string;
  description: string;
}> = [
  {
    value: "하",
    title: "하",
    description: "핵심 개념과 정의 중심으로 처음 복습하는 학생도 풀 수 있게 생성합니다."
  },
  {
    value: "중",
    title: "중",
    description: "개념 이해와 간단한 응용 중심으로 단순 암기보다 이해도를 확인합니다."
  },
  {
    value: "상",
    title: "상",
    description: "실전형과 심화 문제 중심으로 시험 대비에 맞게 조금 더 깊게 다룹니다."
  }
];

function formatSeconds(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return `${minutes}분 ${rest}초`;
}

function downloadJson(fileName: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
}

function analyzeQuestion(isCorrect: boolean, elapsedSeconds: number) {
  if (!isCorrect && elapsedSeconds >= 45) return "개념 이해 부족 가능성";
  if (!isCorrect && elapsedSeconds < 20) return "실수 또는 오개념 가능성";
  if (isCorrect && elapsedSeconds >= 45) return "이해는 했지만 숙련도 부족 가능성";
  return isCorrect ? "안정적으로 이해한 문제" : "추가 복습이 필요한 문제";
}

export default function Home() {
  const [step, setStep] = useState<"upload" | "difficulty" | "quiz" | "report">("upload");
  const [fileName, setFileName] = useState("");
  const [pdfText, setPdfText] = useState("");
  const [pdfSummary, setPdfSummary] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [questions, setQuestions] = useState<StudyQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentIndex, setCurrentIndex] = useState(0);
  const [questionTimes, setQuestionTimes] = useState<Record<string, number>>({});
  const [questionStartedAt, setQuestionStartedAt] = useState(Date.now());
  const [quizStartedAt, setQuizStartedAt] = useState<number | null>(null);
  const [report, setReport] = useState<StudyReport | null>(null);
  const [uploadStatus, setUploadStatus] = useState("");
  const [generationStatus, setGenerationStatus] = useState("");
  const [gradingStatus, setGradingStatus] = useState("");
  const [saveStatus, setSaveStatus] = useState("");
  const [error, setError] = useState("");
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const currentQuestion = questions[currentIndex];
  const unansweredCount = useMemo(
    () => questions.filter((question) => !answers[question.id]?.trim()).length,
    [answers, questions]
  );

  async function handleUpload(file?: File) {
    setError("");
    if (!file) return;
    if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
      setError("PDF 파일만 업로드할 수 있어요. 강의자료 파일 형식을 확인해 주세요.");
      return;
    }

    setUploadStatus("PDF 내용을 읽고 있습니다...");
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/extract-pdf", {
        method: "POST",
        body: formData
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "업로드에 실패했습니다.");

      setFileName(data.fileName);
      setPdfText(data.text);
      setPdfSummary(data.summary);
      setStep("difficulty");
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : "업로드 중 문제가 발생했습니다.");
    } finally {
      setUploadStatus("");
    }
  }

  async function generateQuestions() {
    if (!difficulty) return;
    setError("");
    setGenerationStatus("선택한 난이도에 맞춰 문제를 만들고 있습니다...");

    try {
      const response = await fetch("/api/generate-questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: pdfText, difficulty })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "문제 생성에 실패했습니다.");

      setQuestions(data.questions);
      setAnswers({});
      setCurrentIndex(0);
      setQuestionTimes({});
      setQuestionStartedAt(Date.now());
      setQuizStartedAt(Date.now());
      setStep("quiz");
    } catch (generationError) {
      setError(generationError instanceof Error ? generationError.message : "문제 생성 중 문제가 발생했습니다.");
    } finally {
      setGenerationStatus("");
    }
  }

  function recordCurrentQuestionTime() {
    if (!currentQuestion) return;
    const elapsed = Math.max(1, Math.round((Date.now() - questionStartedAt) / 1000));
    setQuestionTimes((previous) => ({
      ...previous,
      [currentQuestion.id]: (previous[currentQuestion.id] || 0) + elapsed
    }));
    setQuestionStartedAt(Date.now());
  }

  function moveQuestion(nextIndex: number) {
    recordCurrentQuestionTime();
    setCurrentIndex(nextIndex);
  }

  async function gradeEssay(question: StudyQuestion, userAnswer: string): Promise<EssayGrade> {
    const response = await fetch("/api/grade-essay", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question: question.question,
        correctAnswer: question.answer,
        userAnswer,
        keywords: question.keywords
      })
    });

    if (!response.ok) {
      return { score: 0, isCorrect: false, feedback: "서술형 채점에 실패했습니다." };
    }

    return response.json();
  }

  async function submitQuiz() {
    setError("");
    if (!currentQuestion) return;

    if (unansweredCount > 0) {
      setError(`아직 답하지 않은 문제가 ${unansweredCount}개 있어요. 모든 문제를 푼 뒤 채점할 수 있습니다.`);
      return;
    }

    recordCurrentQuestionTime();
    setGradingStatus("답안을 채점하고 학습 리포트를 만들고 있습니다...");

    const updatedTimes = {
      ...questionTimes,
      [currentQuestion.id]:
        (questionTimes[currentQuestion.id] || 0) +
        Math.max(1, Math.round((Date.now() - questionStartedAt) / 1000))
    };

    const results: GradedQuestion[] = [];

    for (const question of questions) {
      const userAnswer = answers[question.id] || "";
      const elapsedSeconds = updatedTimes[question.id] || 1;

      if (question.type === "SHORT_ANSWER") {
        const essay = await gradeEssay(question, userAnswer);
        results.push({
          question,
          userAnswer,
          isCorrect: essay.isCorrect,
          score: essay.score,
          maxScore: 10,
          elapsedSeconds,
          analysis: analyzeQuestion(essay.isCorrect, elapsedSeconds),
          essayFeedback: essay.feedback
        });
      } else {
        const isCorrect = userAnswer === question.answer;
        results.push({
          question,
          userAnswer,
          isCorrect,
          score: isCorrect ? 1 : 0,
          maxScore: 1,
          elapsedSeconds,
          analysis: analyzeQuestion(isCorrect, elapsedSeconds)
        });
      }
    }

    const rawScore = results.reduce((sum, item) => sum + item.score, 0);
    const maxScore = results.reduce((sum, item) => sum + item.maxScore, 0);
    const totalScore = Math.round((rawScore / maxScore) * 100);
    const correctCount = results.filter((item) => item.isCorrect).length;
    const wrongCount = results.length - correctCount;
    const totalElapsedSeconds = quizStartedAt ? Math.round((Date.now() - quizStartedAt) / 1000) : 0;

    const wrongConceptCounts = results
      .filter((item) => !item.isCorrect)
      .reduce<Record<string, number>>((acc, item) => {
        acc[item.question.concept] = (acc[item.question.concept] || 0) + 1;
        return acc;
      }, {});

    const weakConcepts = Object.entries(wrongConceptCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([concept]) => concept);

    const feedback =
      totalScore >= 85
        ? "전반적으로 이해도가 높습니다. 오래 걸린 문제 위주로 반복하면 실전 속도가 더 좋아집니다."
        : totalScore >= 60
          ? "핵심 흐름은 잡혀 있습니다. 취약 개념을 다시 읽고 비슷한 문제를 한 번 더 풀어보세요."
          : "기초 개념 복습이 먼저 필요합니다. 오답 해설을 중심으로 정의와 예시를 다시 정리해 보세요.";

    const nextReport: StudyReport = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      fileName,
      difficulty: difficulty || "중",
      totalScore,
      correctCount,
      wrongCount,
      totalElapsedSeconds,
      weakConcepts,
      feedback,
      results
    };

    setReport(nextReport);
    setStep("report");
    setGradingStatus("");
    await saveReport(nextReport);
  }

  async function saveReport(nextReport: StudyReport) {
    setSaveStatus("Firebase Realtime Database에 결과를 저장하고 있습니다...");

    try {
      const response = await fetch(`${firebaseDatabaseUrl.replace(/\/$/, "")}/studyResults/${nextReport.id}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextReport)
      });

      if (!response.ok) throw new Error("저장 실패");
      setSaveStatus("Firebase 저장이 완료되었습니다.");
    } catch {
      setSaveStatus("Firebase 저장에 실패했습니다. 데이터베이스 규칙 또는 네트워크를 확인해 주세요.");
    }
  }

  return (
    <main className="min-h-screen bg-[#f7f9fc]">
      <div className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-5 py-8">
        <header className="mb-8 flex flex-col gap-3 border-b border-slate-200 pb-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-semibold text-blue-700">AI 기반 PDF 학습 지원 웹앱</p>
            <h1 className="mt-2 text-3xl font-bold tracking-normal text-slate-950 sm:text-4xl">
              PDF Study Coach
            </h1>
          </div>
          <p className="max-w-xl text-sm leading-6 text-slate-600">
            강의자료를 업로드하면 내용을 분석하고, 난이도별 문제 생성부터 채점, 취약 개념 리포트,
            다운로드까지 한 흐름으로 도와줍니다.
          </p>
        </header>

        {step === "upload" && (
          <section className="grid flex-1 place-items-center">
            <div className="w-full max-w-2xl rounded-lg border border-slate-200 bg-white p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-slate-950">PDF 업로드</h2>
              <p className="mt-3 text-slate-600">
                강의자료나 학습자료 PDF를 올려 주세요. 텍스트가 포함된 PDF일수록 문제 품질이 좋아집니다.
              </p>
              <input
                ref={fileInputRef}
                className="hidden"
                type="file"
                accept="application/pdf,.pdf"
                onChange={(event) => handleUpload(event.target.files?.[0])}
              />
              <button
                className="mt-8 w-full rounded-md bg-blue-700 px-5 py-4 font-semibold text-white transition hover:bg-blue-800 disabled:cursor-not-allowed disabled:bg-slate-400"
                disabled={Boolean(uploadStatus)}
                onClick={() => fileInputRef.current?.click()}
              >
                {uploadStatus || "PDF 파일 선택하기"}
              </button>
              {error && <p className="mt-4 rounded-md bg-red-50 p-4 text-sm text-red-700">{error}</p>}
            </div>
          </section>
        )}

        {step === "difficulty" && (
          <section className="flex-1">
            <div className="rounded-lg border border-slate-200 bg-white p-6">
              <p className="text-sm font-semibold text-green-700">PDF 분석 완료</p>
              <h2 className="mt-2 text-2xl font-bold text-slate-950">{fileName}</h2>
              <p className="mt-3 line-clamp-3 text-sm leading-6 text-slate-600">{pdfSummary}</p>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-3">
              {difficultyCards.map((card) => (
                <button
                  key={card.value}
                  className={`rounded-lg border p-6 text-left transition ${
                    difficulty === card.value
                      ? "border-blue-700 bg-blue-50 ring-2 ring-blue-200"
                      : "border-slate-200 bg-white hover:border-blue-300"
                  }`}
                  onClick={() => setDifficulty(card.value)}
                >
                  <span className="text-2xl font-bold text-slate-950">{card.title}</span>
                  <p className="mt-3 text-sm leading-6 text-slate-600">{card.description}</p>
                </button>
              ))}
            </div>

            <button
              className="mt-6 rounded-md bg-blue-700 px-6 py-3 font-semibold text-white transition hover:bg-blue-800 disabled:cursor-not-allowed disabled:bg-slate-400"
              disabled={!difficulty || Boolean(generationStatus)}
              onClick={generateQuestions}
            >
              {generationStatus || "문제 생성하기"}
            </button>
            {error && (
              <div className="mt-4 rounded-md bg-red-50 p-4 text-sm text-red-700">
                <p>{error}</p>
                <button className="mt-3 font-semibold underline" onClick={generateQuestions}>
                  다시 시도
                </button>
              </div>
            )}
          </section>
        )}

        {step === "quiz" && currentQuestion && (
          <section className="flex-1">
            <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-semibold text-blue-700">
                  {currentIndex + 1} / {questions.length}
                </p>
                <h2 className="text-2xl font-bold text-slate-950">문제 풀이</h2>
              </div>
              <p className="rounded-md bg-white px-4 py-2 text-sm text-slate-600">
                답하지 않은 문제: {unansweredCount}개
              </p>
            </div>

            <article className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex flex-wrap gap-2 text-xs font-semibold">
                <span className="rounded-full bg-slate-100 px-3 py-1 text-slate-700">{currentQuestion.id}</span>
                <span className="rounded-full bg-blue-50 px-3 py-1 text-blue-700">{currentQuestion.type}</span>
                <span className="rounded-full bg-green-50 px-3 py-1 text-green-700">
                  {currentQuestion.concept}
                </span>
              </div>
              <h3 className="mt-5 text-xl font-bold leading-8 text-slate-950">{currentQuestion.question}</h3>

              <div className="mt-6 space-y-3">
                {currentQuestion.type === "SHORT_ANSWER" ? (
                  <textarea
                    className="min-h-40 w-full rounded-md border border-slate-300 p-4 outline-none focus:border-blue-600 focus:ring-2 focus:ring-blue-100"
                    placeholder="답안을 입력하세요."
                    value={answers[currentQuestion.id] || ""}
                    onChange={(event) =>
                      setAnswers((previous) => ({ ...previous, [currentQuestion.id]: event.target.value }))
                    }
                  />
                ) : (
                  currentQuestion.choices.map((choice) => (
                    <button
                      key={choice}
                      className={`w-full rounded-md border px-4 py-3 text-left transition ${
                        answers[currentQuestion.id] === choice
                          ? "border-blue-700 bg-blue-50 text-blue-900"
                          : "border-slate-200 hover:border-blue-300"
                      }`}
                      onClick={() => setAnswers((previous) => ({ ...previous, [currentQuestion.id]: choice }))}
                    >
                      {choice}
                    </button>
                  ))
                )}
              </div>
            </article>

            {error && <p className="mt-4 rounded-md bg-amber-50 p-4 text-sm text-amber-800">{error}</p>}
            {gradingStatus && <p className="mt-4 rounded-md bg-blue-50 p-4 text-sm text-blue-800">{gradingStatus}</p>}

            <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
              <button
                className="rounded-md border border-slate-300 px-5 py-3 font-semibold text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                disabled={currentIndex === 0}
                onClick={() => moveQuestion(currentIndex - 1)}
              >
                이전
              </button>
              <div className="flex gap-3">
                <button
                  className="rounded-md border border-slate-300 px-5 py-3 font-semibold text-slate-700 disabled:cursor-not-allowed disabled:opacity-40"
                  disabled={currentIndex === questions.length - 1}
                  onClick={() => moveQuestion(currentIndex + 1)}
                >
                  다음
                </button>
                <button
                  className="rounded-md bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800 disabled:cursor-not-allowed disabled:bg-slate-400"
                  disabled={Boolean(gradingStatus)}
                  onClick={submitQuiz}
                >
                  채점하기
                </button>
              </div>
            </div>
          </section>
        )}

        {step === "report" && report && (
          <section className="flex-1">
            <div className="grid gap-4 sm:grid-cols-4">
              <div className="rounded-lg bg-white p-5 shadow-sm">
                <p className="text-sm text-slate-500">총점</p>
                <strong className="mt-2 block text-3xl text-blue-700">{report.totalScore}점</strong>
              </div>
              <div className="rounded-lg bg-white p-5 shadow-sm">
                <p className="text-sm text-slate-500">정답</p>
                <strong className="mt-2 block text-3xl text-green-700">{report.correctCount}개</strong>
              </div>
              <div className="rounded-lg bg-white p-5 shadow-sm">
                <p className="text-sm text-slate-500">오답</p>
                <strong className="mt-2 block text-3xl text-red-700">{report.wrongCount}개</strong>
              </div>
              <div className="rounded-lg bg-white p-5 shadow-sm">
                <p className="text-sm text-slate-500">풀이 시간</p>
                <strong className="mt-2 block text-2xl text-slate-950">
                  {formatSeconds(report.totalElapsedSeconds)}
                </strong>
              </div>
            </div>

            <div className="mt-5 rounded-lg border border-slate-200 bg-white p-6">
              <h2 className="text-2xl font-bold text-slate-950">학습 분석 리포트</h2>
              <p className="mt-3 leading-7 text-slate-700">{report.feedback}</p>
              <div className="mt-4">
                <p className="font-semibold text-slate-900">취약 개념</p>
                <p className="mt-2 text-slate-600">
                  {report.weakConcepts.length ? report.weakConcepts.join(", ") : "뚜렷한 취약 개념이 없습니다."}
                </p>
              </div>
              <p className="mt-4 text-sm text-slate-600">{saveStatus}</p>
              <div className="mt-5 flex flex-wrap gap-3">
                <button
                  className="rounded-md bg-slate-900 px-5 py-3 font-semibold text-white"
                  onClick={() => downloadJson("questions.json", questions)}
                >
                  문제 다운로드
                </button>
                <button
                  className="rounded-md bg-blue-700 px-5 py-3 font-semibold text-white"
                  onClick={() => downloadJson("study-report.json", report)}
                >
                  리포트 다운로드
                </button>
              </div>
            </div>

            <div className="mt-5 space-y-4">
              {report.results.map((item) => (
                <article key={item.question.id} className="rounded-lg border border-slate-200 bg-white p-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p className="font-bold text-slate-950">
                      {item.question.id}. {item.isCorrect ? "정답" : "오답"}
                    </p>
                    <span className="rounded-full bg-slate-100 px-3 py-1 text-sm text-slate-700">
                      {item.score}/{item.maxScore}점 · {formatSeconds(item.elapsedSeconds)}
                    </span>
                  </div>
                  <p className="mt-3 font-semibold text-slate-900">{item.question.question}</p>
                  <p className="mt-3 text-sm text-slate-600">내 답안: {item.userAnswer}</p>
                  <p className="mt-2 text-sm text-slate-600">정답: {item.question.answer}</p>
                  <p className="mt-2 text-sm leading-6 text-slate-700">해설: {item.question.explanation}</p>
                  <p className="mt-2 text-sm text-blue-700">분석: {item.analysis}</p>
                  {item.essayFeedback && <p className="mt-2 text-sm text-slate-600">서술형 피드백: {item.essayFeedback}</p>}
                </article>
              ))}
            </div>
          </section>
        )}
      </div>
    </main>
  );
}
