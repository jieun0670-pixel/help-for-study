export type Difficulty = "하" | "중" | "상";
export type QuestionType = "OX" | "MULTIPLE_CHOICE" | "SHORT_ANSWER";

export type StudyQuestion = {
  id: string;
  type: QuestionType;
  question: string;
  choices: string[];
  answer: string;
  explanation: string;
  concept: string;
  difficulty: Difficulty;
  keywords?: string[];
};

export type EssayGrade = {
  score: number;
  isCorrect: boolean;
  feedback: string;
};

export type GradedQuestion = {
  question: StudyQuestion;
  userAnswer: string;
  isCorrect: boolean;
  score: number;
  maxScore: number;
  elapsedSeconds: number;
  analysis: string;
  essayFeedback?: string;
};

export type StudyReport = {
  id: string;
  createdAt: string;
  fileName: string;
  difficulty: Difficulty;
  totalScore: number;
  correctCount: number;
  wrongCount: number;
  totalElapsedSeconds: number;
  weakConcepts: string[];
  feedback: string;
  results: GradedQuestion[];
};
